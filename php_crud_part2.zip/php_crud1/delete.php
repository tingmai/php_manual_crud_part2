<?php


     $id=$_GET['id'];

	include("config/db.php");
	$res=$conn->query("delete from products where id=$id");

     if($res){

        	header("location:index.php");
        }
        else{

        	echo "<script> alert('Sorry..:( Could not delete..')</script>";
        }



	?>
